Please note that the private token in `private.py` may only work for my computer. 
Also, the best way to demo the bot is to invite it to your server at this 
[link](https://discord.com/api/oauth2/authorize?client_id=959889388639240203&permissions=534723946560&scope=bot).
If you do indeed attempt to run the bot off your computer, please navigate to this folder
and run `python main.py`.
Also, if any questions arise, please reach out to
kd#2122 or ye11ow_flash#0705 on discord.